import gym
import copy
import numpy as np
import torch
import torch.nn as nn
import torch.nn.functional as F
import matplotlib.pyplot as plt
from torch.utils.tensorboard import SummaryWriter

# 设置设备（CUDA优先）
device = torch.device("cuda" if torch.cuda.is_available() else "cpu")

# 经验回放缓冲区
class ReplayBuffer(object):
	def __init__(self, state_dim, action_dim, max_size=int(1e6)):
		self.max_size = max_size
		self.ptr = 0  # 当前写入位置
		self.size = 0  # 已存储经验数量

		self.state = np.zeros((max_size, state_dim))
		self.action = np.zeros((max_size, action_dim))
		self.reward = np.zeros((max_size, 1))
		self.next_state = np.zeros((max_size, state_dim))
		self.dead = np.zeros((max_size, 1))
		self.device = torch.device("cuda" if torch.cuda.is_available() else "cpu")

	# 添加经验
	def add(self, state, action, reward, next_state, dead):
		# 按 ptr 写入，满后覆盖，并更新 size 和 ptr
		self.state[self.ptr] = state
		self.action[self.ptr] = action
		self.reward[self.ptr] = reward
		self.next_state[self.ptr] = next_state
		self.dead[self.ptr] = dead
		self.ptr = (self.ptr + 1) % self.max_size
		self.size = min(self.size + 1, self.max_size)

	# 采样 batch
	def sample(self, batch_size):
		# 随机采样 batch，转换为 GPU 上的 Tensor 返回
		ind = np.random.randint(0, self.size, size=batch_size)
		return (
			torch.FloatTensor(self.state[ind]).to(self.device),
			torch.FloatTensor(self.action[ind]).to(self.device),
			torch.FloatTensor(self.reward[ind]).to(self.device),
			torch.FloatTensor(self.next_state[ind]).to(self.device),
			torch.FloatTensor(self.dead[ind]).to(self.device)
		)

# 策略网络（Actor）
class Actor(nn.Module):
	def __init__(self, state_dim, action_dim, net_width, maxaction):
		super(Actor, self).__init__()
		self.l1 = nn.Linear(state_dim, net_width)
		self.l2 = nn.Linear(net_width, net_width)
		self.l3 = nn.Linear(net_width, action_dim)
		self.maxaction = maxaction

	def forward(self, state):
		a = torch.tanh(self.l1(state))
		a = torch.tanh(self.l2(a))
		a = torch.tanh(self.l3(a)) * self.maxaction
		return a

# Q函数网络（Critic）
class Q_Critic(nn.Module):
	def __init__(self, state_dim, action_dim, net_width):
		super(Q_Critic, self).__init__()
		# 第一个 Q 网络
		self.l1 = nn.Linear(state_dim + action_dim, net_width)
		self.l2 = nn.Linear(net_width, net_width)
		self.l3 = nn.Linear(net_width, 1)
		# 第二个 Q 网络
		self.l4 = nn.Linear(state_dim + action_dim, net_width)
		self.l5 = nn.Linear(net_width, net_width)
		self.l6 = nn.Linear(net_width, 1)

	def forward(self, state, action):
		sa = torch.cat([state, action], 1)
		q1 = F.relu(self.l1(sa))
		q1 = F.relu(self.l2(q1))
		q1 = self.l3(q1)
		q2 = F.relu(self.l4(sa))
		q2 = F.relu(self.l5(q2))
		q2 = self.l6(q2)
		return q1, q2

	def Q1(self, state, action):
		sa = torch.cat([state, action], 1)
		q1 = F.relu(self.l1(sa))
		q1 = F.relu(self.l2(q1))
		q1 = self.l3(q1)
		return q1

# TD3算法主体
class TD3(object):
	def __init__(self, env_with_Dead, state_dim, action_dim, max_action, gamma=0.99, net_width=128, a_lr=1e-4, c_lr=1e-4, Q_batchsize = 256):
		self.actor = Actor(state_dim, action_dim, net_width, max_action).to(device)
		self.actor_optimizer = torch.optim.Adam(self.actor.parameters(), lr=a_lr)
		self.actor_target = copy.deepcopy(self.actor)

		self.q_critic = Q_Critic(state_dim, action_dim, net_width).to(device)
		self.q_critic_optimizer = torch.optim.Adam(self.q_critic.parameters(), lr=c_lr)
		self.q_critic_target = copy.deepcopy(self.q_critic)

		self.env_with_Dead = env_with_Dead
		self.action_dim = action_dim
		self.max_action = max_action
		self.gamma = gamma
		# TD3 特性：给目标动作加噪声并裁剪
		self.policy_noise = 0.2 * max_action
		self.noise_clip = 0.5 * max_action
		self.tau = 0.005
		self.Q_batchsize = Q_batchsize
		self.delay_counter = -1
		self.delay_freq = 1 # 控制 actor 更新频率（通常为 2～3，1 是每轮都更新）

	def select_action(self, state):
		with torch.no_grad():
			state = torch.FloatTensor(state).reshape(1, -1).to(device)
			a = self.actor(state)
		return a.cpu().numpy().flatten()

	def train(self,replay_buffer):
		self.delay_counter += 1
		with torch.no_grad():
			s, a, r, s_prime, dead_mask = replay_buffer.sample(self.Q_batchsize)
			noise = (torch.randn_like(a) * self.policy_noise).clamp(-self.noise_clip, self.noise_clip)
			smoothed_target_a = (self.actor_target(s_prime) + noise).clamp(-self.max_action, self.max_action)
			target_Q1, target_Q2 = self.q_critic_target(s_prime, smoothed_target_a)
			target_Q = torch.min(target_Q1, target_Q2)
			# 如果环境有死亡信号（done=True）时，不能再继续加 future Q
			if self.env_with_Dead:
				target_Q = r + (1 - dead_mask) * self.gamma * target_Q
			else:
				target_Q = r + self.gamma * target_Q

		current_Q1, current_Q2 = self.q_critic(s, a)
		q_loss = F.mse_loss(current_Q1, target_Q) + F.mse_loss(current_Q2, target_Q)
		self.q_critic_optimizer.zero_grad()
		q_loss.backward()
		self.q_critic_optimizer.step()

		if self.delay_counter == self.delay_freq:
			a_loss = -self.q_critic.Q1(s,self.actor(s)).mean()
			self.actor_optimizer.zero_grad()
			a_loss.backward()
			self.actor_optimizer.step()

			for param, target_param in zip(self.q_critic.parameters(), self.q_critic_target.parameters()):
				target_param.data.copy_(self.tau * param.data + (1 - self.tau) * target_param.data)
			for param, target_param in zip(self.actor.parameters(), self.actor_target.parameters()):
				target_param.data.copy_(self.tau * param.data + (1 - self.tau) * target_param.data)
			self.delay_counter = -1

	def save(self,episode):
		torch.save(self.actor.state_dict(), "ppo_actor{}.pth".format(episode))
		torch.save(self.q_critic.state_dict(), "ppo_q_critic{}.pth".format(episode))

	def load(self,episode):
		self.actor.load_state_dict(torch.load("ppo_actor{}.pth".format(episode)))
		self.q_critic.load_state_dict(torch.load("ppo_q_critic{}.pth".format(episode)))

# 主函数
def main(seed):
	env_with_Dead = True
	# env = gym.make('BipedalWalkerHardcore-v3', render_mode='human')
	env = gym.make('BipedalWalkerHardcore-v3')
	state_dim = env.observation_space.shape[0]
	action_dim = env.action_space.shape[0]
	max_action = float(env.action_space.high[0])

	expl_noise = 0.25  # 初始探索噪声
	render = True  # 是否渲染环境 # 新版本 变为 无效语句
	Loadmodel = True  # 是否加载模型

	ModelIdex = 3600  # 加载模型的编号
	Max_episode = 2000000  # 最大训练轮数
	save_interval = 400  # 每隔多少次保存一次模型

	if seed:
		torch.manual_seed(seed)
		env.reset(seed=seed)
		np.random.seed(seed)

	writer = SummaryWriter(log_dir='runs/exp')

	kwargs = {
		"env_with_Dead":env_with_Dead,
		"state_dim": state_dim,
		"action_dim": action_dim,
		"max_action": max_action,
		"gamma": 0.99,
		"net_width": 200,
		"a_lr": 1e-4,
		"c_lr": 1e-4,
		"Q_batchsize":256,
	}
	model = TD3(**kwargs)
	if Loadmodel: model.load(ModelIdex)
	replay_buffer = ReplayBuffer(state_dim, action_dim)
	all_ep_r = []

	for episode in range(Max_episode):
		s, info = env.reset()
		done = False
		ep_r = 0
		steps = 0
		expl_noise *= 0.999
		while not done:
			steps += 1
			if render:
				a = model.select_action(s)
				s_prime, r, done, truncated, info = env.step(a)
				env.render()
			else:
				a = (model.select_action(s) + np.random.normal(0, max_action * expl_noise, size=action_dim)).clip(-max_action, max_action)
				s_prime, r, done, truncated, info = env.step(a)
				if r <= -100:
					r = -1
					replay_buffer.add(s, a, r, s_prime, True)
				else:
					replay_buffer.add(s, a, r, s_prime, False)
				if replay_buffer.size > 2000:
					model.train(replay_buffer)
				if truncated:
					break
			s = s_prime
			ep_r += r

		if (episode+1)%save_interval == 0:
			model.save(episode + 1)

		if episode == 0:
			all_ep_r.append(ep_r)
		else:
			all_ep_r.append(all_ep_r[-1]*0.9 + ep_r*0.1)

		writer.add_scalar('s_ep_r', all_ep_r[-1], episode)
		writer.add_scalar('ep_r', ep_r, episode)
		writer.add_scalar('exploare', expl_noise, episode)

		print('seed:', seed, 'episode:', episode, 'score:', ep_r, 'step:', steps, 'max:', max(all_ep_r))

	env.close()

if __name__ == '__main__':
	main(seed=1)