---

# PPO-RL-Env-Demo

本项目展示了使用 **Proximal Policy Optimization (PPO)** 算法在多个典型强化学习环境中的应用。环境包括离散动作空间与连续动作空间，旨在为初学者和研究人员提供 PPO 在不同类型环境下的参考实现。

## ✅ 项目环境依赖

请确保安装以下 Python 库：

```bash
pip install numpy matplotlib torch gymnasium pygame tqdm
```

### 已使用的依赖包说明：

* **numpy**：用于数值计算。
* **matplotlib**：用于训练过程中的可视化。
* **gymnasium**：用于强化学习环境（替代旧版 `gym`）。

  * **Atari**（仅支持离散动作空间）
  * **Mujoco**（支持离散与连续动作空间）
  * **Box2D**（支持离散与连续动作空间）
* **torch**：实现 PPO 算法的深度神经网络框架。
* **pygame**：用于渲染训练窗口，查看智能体与环境的交互。
* **tqdm**：用于显示训练进度条。

> 备注：本环境未进行大规模或系统性实验，主要用于 PPO 在不同动作空间环境下的测试示例。

---

## 📦 示例环境与任务

本项目在以下代表性环境中实现了 PPO：

| 环境来源   | 环境名称               | 动作空间 |
| ------ | ------------------ | ---- |
| Box2D  | `LunarLander-v2`   | 离散   |
| Mujoco | `HalfCheetah-v4`   | 连续   |
| Box2D  | `BipedalWalker-v3` | 连续   |

每个环境对应一个 PPO 实现文件，包含训练与测试逻辑。

---

## 🚀 使用说明

训练示例：

```bash
python train_lunar.py        # 训练 LunarLander
python train_halfcheetah.py  # 训练 HalfCheetah
python train_bipedal.py      # 训练 BipedalWalker
```

每个训练脚本会在终端显示训练进度，并可选择使用 pygame 打开交互窗口查看智能体表现。

---

## 📌 注意事项

* 本项目主要用于学习与研究 PPO 的实现，并非最优模型或性能 benchmark。
* 请确保已正确安装 Mujoco 相关依赖并获得许可，否则 Mujoco 环境将无法正常运行。

---

## 📁 目录结构示意（可补充）

```
ppo_rl_env_demo/
├── models/               # 保存训练好的模型
├── utils/                # 工具函数，例如 buffer、网络结构
├── train_lunar.py        # PPO 在 LunarLander 的训练脚本
├── train_halfcheetah.py  # PPO 在 HalfCheetah 的训练脚本
├── train_bipedal.py      # PPO 在 BipedalWalker 的训练脚本
└── README.md
```

---

如需进一步实验对比或扩展支持的环境，可在此基础上灵活修改。

---