import gymnasium as gym

env = gym.make('HalfCheetah-v4', render_mode = "human")
# env = gym.make('Walker2d-v4', render_mode = "human")

while True:
    s, _ = env.reset()
    done = False
    while not done:
        a = env.action_space.sample()
        s_next, r, dw, tr, info = env.step(a)
        done = (dw or tr)
        print(s)