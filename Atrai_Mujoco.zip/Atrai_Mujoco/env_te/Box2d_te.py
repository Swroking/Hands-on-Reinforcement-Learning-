import gymnasium as gym

env = gym.make('BipedalWalker-v3', render_mode = "human")

while True:
    s, _ = env.reset()
    done = False
    while not done:
        a = env.action_space.sample()
        s_next, r, dw, tr, info = env.step(a)
        done = (dw or tr)