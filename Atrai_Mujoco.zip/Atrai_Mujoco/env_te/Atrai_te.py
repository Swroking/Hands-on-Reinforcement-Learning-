import gymnasium as gym

env = gym.make('ALE/Breakout-v5', render_mode = "human")

while True:
    s, _ = env.reset()
    done = False
    while not done:
        a = env.action_space.sample()
        s_next, r, dw, tr, info = env.step(a)
        done = (dw or tr)

# pip install gymnasium[atari,accept-rom-license]==0.28.0